import { useState } from 'react';
import { AuthScreen } from '@/app/components/AuthScreen';
import { HomeScreen } from '@/app/components/HomeScreen';
import { EmergencyActiveScreen } from '@/app/components/EmergencyActiveScreen';
import { LocationSharingScreen } from '@/app/components/LocationSharingScreen';
import { ProximityAlertScreen } from '@/app/components/ProximityAlertScreen';
import { TrustedContactsScreen } from '@/app/components/TrustedContactsScreen';
import { SettingsScreen } from '@/app/components/SettingsScreen';
import { BottomNavigation } from '@/app/components/BottomNavigation';
import { getTranslation, type Language, LANGUAGES } from '@/app/translations';

export type Screen = 'home' | 'location' | 'proximity' | 'contacts' | 'settings';

export interface TrustedContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
  autoAlert: boolean;
}

export interface Settings {
  locationSharing: boolean;
  communityAlerts: boolean;
  dataRetention: '30days' | '90days' | '1year';
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<Language>(LANGUAGES[0]); // Default to English
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [emergencyActive, setEmergencyActive] = useState(false);
  const [emergencyStartTime, setEmergencyStartTime] = useState<number | null>(null);
  const [locationSharing, setLocationSharing] = useState(false);
  
  const t = getTranslation(currentLanguage.code);
  
  const [trustedContacts, setTrustedContacts] = useState<TrustedContact[]>([
    {
      id: '1',
      name: 'Amma',
      phone: '+91 98765 43210',
      relation: 'Mother',
      autoAlert: true
    },
    {
      id: '2',
      name: 'Appa',
      phone: '+91 98765 43211',
      relation: 'Father',
      autoAlert: true
    }
  ]);

  const [settings, setSettings] = useState<Settings>({
    locationSharing: true,
    communityAlerts: false,
    dataRetention: '90days'
  });

  const handleSOSPress = () => {
    setEmergencyActive(true);
    setEmergencyStartTime(Date.now());
    setLocationSharing(true);
  };

  const handleCancelEmergency = () => {
    setEmergencyActive(false);
    setEmergencyStartTime(null);
    setLocationSharing(false);
  };

  const handleStopLocationSharing = () => {
    setLocationSharing(false);
  };

  const handleAddContact = (contact: Omit<TrustedContact, 'id'>) => {
    const newContact = {
      ...contact,
      id: Date.now().toString()
    };
    setTrustedContacts([...trustedContacts, newContact]);
  };

  const handleRemoveContact = (id: string) => {
    setTrustedContacts(trustedContacts.filter(c => c.id !== id));
  };

  const handleToggleAutoAlert = (id: string) => {
    setTrustedContacts(trustedContacts.map(c => 
      c.id === id ? { ...c, autoAlert: !c.autoAlert } : c
    ));
  };

  const handleUpdateSettings = (newSettings: Partial<Settings>) => {
    setSettings({ ...settings, ...newSettings });
  };

  // Show authentication screen first
  if (!isAuthenticated) {
    return (
      <div className="relative h-screen w-full bg-white overflow-hidden font-['Roboto',sans-serif]">
        <div className="max-w-[428px] mx-auto h-full relative bg-white">
          <AuthScreen 
            onAuthSuccess={() => setIsAuthenticated(true)}
            currentLanguage={currentLanguage}
            onLanguageChange={setCurrentLanguage}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-screen w-full bg-white overflow-hidden font-['Roboto',sans-serif]">
      {/* Main content area - mobile viewport */}
      <div className="max-w-[428px] mx-auto h-full relative bg-white flex flex-col">
        {/* Screen content */}
        <div className="flex-1 overflow-y-auto pb-20">
          {currentScreen === 'home' && (
            <HomeScreen 
              onSOSPress={handleSOSPress}
              safetyStatus={t.safe}
              t={t}
            />
          )}
          {currentScreen === 'location' && (
            <LocationSharingScreen 
              isSharing={locationSharing}
              onStopSharing={handleStopLocationSharing}
              t={t}
            />
          )}
          {currentScreen === 'proximity' && (
            <ProximityAlertScreen t={t} />
          )}
          {currentScreen === 'contacts' && (
            <TrustedContactsScreen 
              contacts={trustedContacts}
              onAddContact={handleAddContact}
              onRemoveContact={handleRemoveContact}
              onToggleAutoAlert={handleToggleAutoAlert}
              t={t}
            />
          )}
          {currentScreen === 'settings' && (
            <SettingsScreen 
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              currentLanguage={currentLanguage}
              onLanguageChange={setCurrentLanguage}
              t={t}
            />
          )}
        </div>

        {/* Bottom Navigation */}
        <BottomNavigation 
          currentScreen={currentScreen}
          onNavigate={setCurrentScreen}
          t={t}
        />

        {/* Emergency Active Overlay */}
        {emergencyActive && (
          <EmergencyActiveScreen 
            startTime={emergencyStartTime!}
            onCancel={handleCancelEmergency}
            t={t}
          />
        )}
      </div>
    </div>
  );
}

export default App;
