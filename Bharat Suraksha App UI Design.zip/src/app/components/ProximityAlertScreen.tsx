import { AlertTriangle, Phone, Shield, Info } from 'lucide-react';
import type { Translations } from '@/app/translations';

interface ProximityAlertScreenProps {
  t: Translations;
}

export function ProximityAlertScreen({ t }: ProximityAlertScreenProps) {
  const handleCallPolice = () => {
    alert('Calling Police 112...');
  };

  const handleAcknowledge = () => {
    alert('Thank you for acknowledging this alert. Police have been notified.');
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Alert banner with vibration indicator */}
      <div className="bg-[#FF6B00] text-white px-6 py-6 shadow-lg animate-pulse">
        <div className="flex items-center gap-3 mb-3">
          <div className="bg-white/30 p-3 rounded-full">
            <AlertTriangle className="w-10 h-10" strokeWidth={3} />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-bold">⚠️ Emergency Alert</h2>
            <p className="text-sm opacity-95">Possible emergency nearby</p>
          </div>
          <div className="flex flex-col gap-1">
            <div className="w-3 h-3 bg-white rounded-full animate-bounce"></div>
            <div className="w-3 h-3 bg-white rounded-full animate-bounce delay-100"></div>
            <div className="w-3 h-3 bg-white rounded-full animate-bounce delay-200"></div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* Alert message */}
        <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-6 mb-6">
          <div className="flex items-start gap-3 mb-4">
            <AlertTriangle className="w-7 h-7 text-amber-600 flex-shrink-0" />
            <div className="flex-1">
              <h3 className="text-xl font-bold text-amber-900 mb-3">
                Possible Emergency Nearby
              </h3>
              <p className="text-amber-800 text-base mb-4">
                An emergency alert has been triggered within your vicinity.
              </p>
              <p className="text-amber-800 font-bold">
                Please inform police or provide safe assistance if you can.
              </p>
            </div>
          </div>
        </div>

        {/* Privacy Protection Notice */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-5 mb-6">
          <div className="flex items-start gap-3">
            <Shield className="w-6 h-6 text-blue-600 flex-shrink-0" />
            <div className="flex-1">
              <h3 className="font-bold text-blue-900 mb-2">
                Privacy Protected
              </h3>
              <ul className="space-y-1.5 text-sm text-blue-800">
                <li>• No victim identity revealed</li>
                <li>• No exact address shared</li>
                <li>• No suspect information</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-gray-50 border-2 border-gray-200 rounded-2xl p-6 mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2 text-lg">
            <Info className="w-6 h-6 text-gray-600" />
            What You Can Do
          </h3>
          <ul className="space-y-3 text-gray-700">
            <li className="flex items-start gap-3">
              <span className="text-[#DC143C] font-bold text-xl">1.</span>
              <span>Call police immediately (112) if you can assist safely</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#DC143C] font-bold text-xl">2.</span>
              <span>Do not put yourself in danger - your safety comes first</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#DC143C] font-bold text-xl">3.</span>
              <span>Stay alert and inform nearby authorities or security</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-[#DC143C] font-bold text-xl">4.</span>
              <span>If safe, look out for anyone who may need help</span>
            </li>
          </ul>
        </div>

        {/* Action buttons */}
        <div className="space-y-3 mb-6">
          <button
            onClick={handleCallPolice}
            className="w-full bg-[#DC143C] text-white py-5 rounded-2xl font-bold shadow-lg active:bg-[#B81030] transition-colors flex items-center justify-center gap-3"
          >
            <Phone className="w-6 h-6" />
            Call Police (112) Immediately
          </button>

          <button
            onClick={handleAcknowledge}
            className="w-full bg-[#0D47A1] text-white py-5 rounded-2xl font-bold shadow-lg active:bg-[#0A3780] transition-colors flex items-center justify-center gap-3"
          >
            <Shield className="w-6 h-6" />
            I Acknowledge This Alert
          </button>
        </div>

        {/* Safety reminder */}
        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-5">
          <p className="text-sm text-red-800 text-center font-bold">
            ⚠️ WARNING: Only provide assistance if it is safe to do so. Do not take any action that could put you at risk.
          </p>
        </div>
      </div>
    </div>
  );
}
