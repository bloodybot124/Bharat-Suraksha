import { useState } from 'react';
import { UserPlus, Phone, Trash2, Bell, BellOff, Users } from 'lucide-react';
import type { TrustedContact } from '@/app/App';
import type { Translations } from '@/app/translations';

interface TrustedContactsScreenProps {
  contacts: TrustedContact[];
  onAddContact: (contact: Omit<TrustedContact, 'id'>) => void;
  onRemoveContact: (id: string) => void;
  onToggleAutoAlert: (id: string) => void;
  t: Translations;
}

export function TrustedContactsScreen({ 
  contacts, 
  onAddContact, 
  onRemoveContact, 
  onToggleAutoAlert,
  t
}: TrustedContactsScreenProps) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newContact, setNewContact] = useState({
    name: '',
    phone: '',
    relation: '',
    autoAlert: true
  });

  const handleAddContact = () => {
    if (newContact.name && newContact.phone) {
      onAddContact(newContact);
      setNewContact({ name: '', phone: '', relation: '', autoAlert: true });
      setShowAddDialog(false);
    }
  };

  const handleCall = (phone: string, name: string) => {
    alert(`Calling ${name} at ${phone}...`);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="bg-[#0D47A1] text-white px-6 py-4">
        <h2 className="text-xl font-bold">Trusted Contacts</h2>
        <p className="text-sm opacity-90 mt-1">Emergency contacts who will be alerted</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* Info card */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm text-blue-800">
                These contacts will receive automatic alerts when you trigger an emergency SOS.
              </p>
            </div>
          </div>
        </div>

        {/* Contacts list */}
        {contacts.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 mb-2">No trusted contacts yet</p>
            <p className="text-sm text-gray-400">Add contacts who should be alerted in emergencies</p>
          </div>
        ) : (
          <div className="space-y-3 mb-6">
            {contacts.map((contact) => (
              <div 
                key={contact.id}
                className="bg-white border-2 border-gray-200 rounded-2xl p-5 shadow-sm"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-800 text-lg">{contact.name}</h3>
                    <p className="text-sm text-gray-600">{contact.relation}</p>
                    <p className="text-sm text-gray-700 mt-1 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      {contact.phone}
                    </p>
                  </div>
                  <button
                    onClick={() => onRemoveContact(contact.id)}
                    className="text-red-600 p-2 hover:bg-red-50 rounded-lg active:bg-red-100 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                  <div className="flex items-center gap-2">
                    {contact.autoAlert ? (
                      <Bell className="w-4 h-4 text-green-600" />
                    ) : (
                      <BellOff className="w-4 h-4 text-gray-400" />
                    )}
                    <span className="text-sm text-gray-700">Auto-alert on emergency</span>
                  </div>
                  <button
                    onClick={() => onToggleAutoAlert(contact.id)}
                    className={`px-4 py-2 rounded-lg font-bold text-sm transition-colors ${
                      contact.autoAlert
                        ? 'bg-green-100 text-green-700 active:bg-green-200'
                        : 'bg-gray-200 text-gray-600 active:bg-gray-300'
                    }`}
                  >
                    {contact.autoAlert ? 'ON' : 'OFF'}
                  </button>
                </div>

                <button
                  onClick={() => handleCall(contact.phone, contact.name)}
                  className="w-full mt-3 bg-[#0D47A1] text-white py-3 rounded-xl font-bold active:bg-[#0A3780] transition-colors flex items-center justify-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  Call {contact.name}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Add button */}
        <button
          onClick={() => setShowAddDialog(true)}
          className="w-full bg-green-600 text-white py-5 rounded-2xl font-bold shadow-lg active:bg-green-700 transition-colors flex items-center justify-center gap-3"
        >
          <UserPlus className="w-6 h-6" />
          Add Trusted Contact
        </button>
      </div>

      {/* Add Contact Dialog */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-6 max-w-[428px] mx-auto">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 className="text-xl font-bold text-gray-800 mb-4">Add Trusted Contact</h3>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-gray-700 mb-2">Name</label>
                <input
                  type="text"
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  placeholder="Enter name"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-[#0D47A1] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-700 mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  placeholder="+91 XXXXX XXXXX"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-[#0D47A1] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-700 mb-2">Relation</label>
                <input
                  type="text"
                  value={newContact.relation}
                  onChange={(e) => setNewContact({ ...newContact, relation: e.target.value })}
                  placeholder="e.g., Mother, Father, Friend"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-xl focus:border-[#0D47A1] focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl">
                <span className="text-sm text-gray-700">Enable auto-alert</span>
                <button
                  onClick={() => setNewContact({ ...newContact, autoAlert: !newContact.autoAlert })}
                  className={`px-5 py-2 rounded-lg font-bold text-sm transition-colors ${
                    newContact.autoAlert
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-300 text-gray-600'
                  }`}
                >
                  {newContact.autoAlert ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowAddDialog(false);
                  setNewContact({ name: '', phone: '', relation: '', autoAlert: true });
                }}
                className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-xl font-bold active:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddContact}
                className="flex-1 bg-[#0D47A1] text-white py-3 rounded-xl font-bold active:bg-[#0A3780] transition-colors"
              >
                Add Contact
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
