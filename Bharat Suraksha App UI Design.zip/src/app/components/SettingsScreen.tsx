import { Shield, MapPin, Bell, Database, Lock, Info, Phone, Languages } from 'lucide-react';
import type { Settings } from '@/app/App';
import type { Translations, Language } from '@/app/translations';

interface SettingsScreenProps {
  settings: Settings;
  onUpdateSettings: (settings: Partial<Settings>) => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  t: Translations;
}

export function SettingsScreen({ settings, onUpdateSettings, currentLanguage, onLanguageChange, t }: SettingsScreenProps) {
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="bg-[#0D47A1] text-white px-6 py-4">
        <h2 className="text-xl font-bold">Settings & Privacy</h2>
        <p className="text-sm opacity-90 mt-1">Control your data and preferences</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* Compliance Banner */}
        <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <Shield className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-bold text-green-900 mb-1">Legal Compliance</h3>
              <p className="text-sm text-green-800">
                <strong>Bharat Suraksha follows Indian privacy and safety laws.</strong> Your data is protected under Government of India regulations.
              </p>
            </div>
          </div>
        </div>

        {/* Authentication Info */}
        <div className="mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Authentication
          </h3>

          <div className="bg-white border-2 border-gray-200 rounded-xl p-5">
            <div className="flex items-start gap-3">
              <Lock className="w-5 h-5 text-[#0D47A1] flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-bold text-gray-800 mb-2">OTP Login Details</h4>
                <p className="text-sm text-gray-600 mb-3">
                  Your account is secured with mobile OTP verification. No password is required or stored.
                </p>
                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-xs text-blue-800">
                    <strong>Mobile Number:</strong> +91 XXXX-XX-1234
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Privacy info banner */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-bold text-blue-900 mb-1">Your Privacy Matters</h3>
              <p className="text-sm text-blue-800">
                Bharat Suraksha is committed to protecting your privacy. All data is encrypted and only shared with your consent.
              </p>
            </div>
          </div>
        </div>

        {/* Consent Settings */}
        <div className="mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Consent & Permissions
          </h3>

          <div className="space-y-3">
            {/* Location Sharing */}
            <div className="bg-white border-2 border-gray-200 rounded-xl p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <MapPin className="w-5 h-5 text-[#0D47A1]" />
                    <h4 className="font-bold text-gray-800">Share Location During Emergency</h4>
                  </div>
                  <p className="text-sm text-gray-600">
                    Automatically share your location when you activate SOS (ON by default)
                  </p>
                </div>
                <button
                  onClick={() => onUpdateSettings({ locationSharing: !settings.locationSharing })}
                  className={`ml-4 px-5 py-2 rounded-lg font-bold text-sm transition-colors flex-shrink-0 ${
                    settings.locationSharing
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-300 text-gray-600'
                  }`}
                >
                  {settings.locationSharing ? 'ON' : 'OFF'}
                </button>
              </div>
              {settings.locationSharing && (
                <div className="bg-green-50 rounded-lg p-3 text-sm text-green-800">
                  ✓ Location will be shared with police and trusted contacts during emergency
                </div>
              )}
            </div>

            {/* Community Alerts */}
            <div className="bg-white border-2 border-gray-200 rounded-xl p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Bell className="w-5 h-5 text-[#FF6B00]" />
                    <h4 className="font-bold text-gray-800">Community Alerts</h4>
                  </div>
                  <p className="text-sm text-gray-600">
                    Receive alerts about nearby emergencies where you can help (OFF by default)
                  </p>
                </div>
                <button
                  onClick={() => onUpdateSettings({ communityAlerts: !settings.communityAlerts })}
                  className={`ml-4 px-5 py-2 rounded-lg font-bold text-sm transition-colors flex-shrink-0 ${
                    settings.communityAlerts
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-300 text-gray-600'
                  }`}
                >
                  {settings.communityAlerts ? 'ON' : 'OFF'}
                </button>
              </div>
              {settings.communityAlerts && (
                <div className="bg-amber-50 rounded-lg p-3 text-sm text-amber-800">
                  ⚠ You will be notified when emergencies occur within 100 meters (no personal details shared)
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Data Retention */}
        <div className="mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Database className="w-5 h-5" />
            Data Auto-Delete
          </h3>

          <div className="bg-white border-2 border-gray-200 rounded-xl p-5">
            <p className="text-sm text-gray-600 mb-4">
              Your emergency history will be automatically deleted after the selected period
            </p>

            <div className="space-y-2">
              <button
                onClick={() => onUpdateSettings({ dataRetention: '30days' })}
                className={`w-full p-4 rounded-xl text-left transition-colors ${
                  settings.dataRetention === '30days'
                    ? 'bg-[#0D47A1] text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                <div className="font-bold">30 Days</div>
                <div className="text-sm opacity-90">Minimum retention period</div>
              </button>

              <button
                onClick={() => onUpdateSettings({ dataRetention: '90days' })}
                className={`w-full p-4 rounded-xl text-left transition-colors ${
                  settings.dataRetention === '90days'
                    ? 'bg-[#0D47A1] text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                <div className="font-bold">90 Days</div>
                <div className="text-sm opacity-90">Recommended for safety</div>
              </button>

              <button
                onClick={() => onUpdateSettings({ dataRetention: '1year' })}
                className={`w-full p-4 rounded-xl text-left transition-colors ${
                  settings.dataRetention === '1year'
                    ? 'bg-[#0D47A1] text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                <div className="font-bold">1 Year</div>
                <div className="text-sm opacity-90">Extended history</div>
              </button>
            </div>
          </div>
        </div>

        {/* Privacy & Safety Labels */}
        <div className="mb-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Info className="w-5 h-5" />
            Privacy & Safety Information
          </h3>

          <div className="space-y-3">
            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-green-900 mb-1">Government Certified</h4>
                  <p className="text-sm text-green-800">
                    This app is certified by the Government of India for emergency response services.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-blue-900 mb-1">End-to-End Encryption</h4>
                  <p className="text-sm text-blue-800">
                    All your data is encrypted and transmitted securely to authorized recipients only.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 border-2 border-purple-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Database className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-purple-900 mb-1">No Third-Party Sharing</h4>
                  <p className="text-sm text-purple-800">
                    Your data is never sold or shared with third parties. It's only used for emergency response.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Legal links */}
        <div className="space-y-2 mb-6">
          <button className="w-full bg-gray-100 text-gray-800 py-4 rounded-xl font-bold active:bg-gray-200 transition-colors">
            Privacy Policy
          </button>
          <button className="w-full bg-gray-100 text-gray-800 py-4 rounded-xl font-bold active:bg-gray-200 transition-colors">
            Terms of Service
          </button>
          <button className="w-full bg-gray-100 text-gray-800 py-4 rounded-xl font-bold active:bg-gray-200 transition-colors">
            Data Protection Guidelines
          </button>
        </div>

        {/* App version */}
        <div className="text-center text-sm text-gray-500 py-4">
          <p>Bharat Suraksha v1.0.0</p>
          <p className="mt-1">© 2026 Government of India</p>
        </div>
      </div>
    </div>
  );
}
