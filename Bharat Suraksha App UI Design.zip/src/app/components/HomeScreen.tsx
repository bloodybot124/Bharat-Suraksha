import { Shield, Phone, AlertCircle, Lock } from 'lucide-react';
import type { Translations } from '@/app/translations';

interface HomeScreenProps {
  onSOSPress: () => void;
  safetyStatus: string;
  t: Translations;
}

export function HomeScreen({ onSOSPress, safetyStatus, t }: HomeScreenProps) {
  const handleEmergencyCall = (number: string, service: string) => {
    // In a real app, this would trigger a phone call
    alert(`Calling ${service} (${number})...`);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header with safety status */}
      <div className="bg-[#0D47A1] text-white px-6 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8" />
            <div>
              <div className="text-sm opacity-90">भारत सुरक्षा</div>
              <div className="font-bold">{t.appName}</div>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-green-600 px-4 py-2 rounded-full">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <span className="text-sm">{safetyStatus}</span>
          </div>
        </div>
      </div>

      {/* Main content area - scrollable with bottom padding for SOS button */}
      <div className="flex-1 overflow-y-auto px-6 pt-6 pb-48">
        <div className="text-center mb-6">
          <h1 className="text-2xl mb-2 text-gray-800">{t.youAreProtected}</h1>
          <p className="text-gray-600">{t.pressSOS}</p>
        </div>

        {/* Privacy Banner */}
        <div className="w-full max-w-sm mx-auto mb-6 bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-blue-800">
                <strong>🔒 {t.privacyProtected}</strong> {t.privacyMessage}
              </p>
            </div>
          </div>
        </div>

        {/* Quick action buttons */}
        <div className="w-full max-w-sm mx-auto">
          <h3 className="text-sm font-bold text-gray-600 mb-3 px-2">{t.emergencyContacts}</h3>
          <div className="space-y-3">
            <button
              onClick={() => handleEmergencyCall('100', 'Police')}
              className="w-full bg-[#0D47A1] text-white py-5 rounded-2xl flex items-center justify-between px-6 active:bg-[#0A3780] transition-colors shadow-lg"
            >
              <div className="flex items-center gap-4">
                <Phone className="w-6 h-6" />
                <div className="text-left">
                  <div className="font-bold text-lg">{t.callPolice}</div>
                  <div className="text-sm opacity-90">{t.policeEmergency}</div>
                </div>
              </div>
              <div className="text-2xl">→</div>
            </button>

            <button
              onClick={() => handleEmergencyCall('1098', 'Childline')}
              className="w-full bg-[#0D47A1] text-white py-5 rounded-2xl flex items-center justify-between px-6 active:bg-[#0A3780] transition-colors shadow-lg"
            >
              <div className="flex items-center gap-4">
                <Phone className="w-6 h-6" />
                <div className="text-left">
                  <div className="font-bold text-lg">{t.callChildline}</div>
                  <div className="text-sm opacity-90">{t.childline}</div>
                </div>
              </div>
              <div className="text-2xl">→</div>
            </button>

            <button
              onClick={() => handleEmergencyCall('181 / 1091', 'Women Helpline')}
              className="w-full bg-[#0D47A1] text-white py-5 rounded-2xl flex items-center justify-between px-6 active:bg-[#0A3780] transition-colors shadow-lg"
            >
              <div className="flex items-center gap-4">
                <Phone className="w-6 h-6" />
                <div className="text-left">
                  <div className="font-bold text-lg">{t.callWomenHelpline}</div>
                  <div className="text-sm opacity-90">{t.womenHelpline}</div>
                </div>
              </div>
              <div className="text-2xl">→</div>
            </button>
          </div>
        </div>
      </div>

      {/* Large SOS button section - fixed at bottom above nav */}
      <div className="absolute bottom-20 left-0 right-0 bg-white border-t-2 border-gray-200 px-6 py-4">
        <button
          onClick={onSOSPress}
          className="w-full bg-[#DC143C] text-white py-8 rounded-3xl shadow-2xl active:bg-[#B81030] transition-all active:scale-95"
        >
          <div className="flex items-center justify-center gap-4">
            <AlertCircle className="w-12 h-12" strokeWidth={3} />
            <div className="text-left">
              <div className="text-3xl font-bold">SOS</div>
              <div className="text-lg opacity-95">{t.sosEmergency}</div>
            </div>
          </div>
        </button>
        <p className="text-xs text-gray-500 text-center mt-3">
          {t.tapToActivate}
        </p>
      </div>
    </div>
  );
}
