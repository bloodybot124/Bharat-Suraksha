import { useState } from 'react';
import { MapPin, Lock, Shield, Eye, Users, Radio, EyeOff } from 'lucide-react';
import type { Translations } from '@/app/translations';

interface LocationSharingScreenProps {
  isSharing: boolean;
  onStopSharing: () => void;
  t: Translations;
}

export function LocationSharingScreen({ isSharing, onStopSharing, t }: LocationSharingScreenProps) {
  const [showPinDialog, setShowPinDialog] = useState(false);
  const [pin, setPin] = useState('');
  const [showMap, setShowMap] = useState(false);

  const handleStopSharingClick = () => {
    setShowPinDialog(true);
  };

  const handlePinSubmit = () => {
    if (pin === '1234') { // Demo PIN
      onStopSharing();
      setShowPinDialog(false);
      setPin('');
    } else {
      alert('Incorrect PIN. Demo PIN is 1234');
      setPin('');
    }
  };

  const handleAlertNearbyPeople = () => {
    // In a real app, this would send push notifications to nearby users
    alert('🚨 SOS Alert sent to all nearby helpers within 100 meters!\n\nNearby community members have been notified of your location and can provide assistance.');
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="bg-[#0D47A1] text-white px-6 py-4">
        <h2 className="text-xl font-bold">Live Location Sharing</h2>
      </div>

      {/* Map area or Protected placeholder */}
      <div className="flex-1 relative bg-gradient-to-br from-blue-50 to-green-50 overflow-hidden">
        {!showMap ? (
          /* Protected Placeholder */
          <div className="h-full flex flex-col items-center justify-center px-6">
            <div className="bg-white rounded-3xl p-8 shadow-2xl max-w-sm w-full text-center">
              <div className="bg-green-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="w-12 h-12 text-green-600" strokeWidth={2.5} />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-800 mb-3">
                Location Protected
              </h2>
              
              <p className="text-gray-600 mb-6">
                🛡️ Your location is securely shared with police only. Your privacy is our priority.
              </p>

              {isSharing && (
                <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-6">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="font-bold text-green-800">Sharing Active</span>
                  </div>
                  <p className="text-sm text-green-700">
                    Police and trusted contacts can see your location
                  </p>
                </div>
              )}

              <button
                onClick={() => setShowMap(true)}
                className="w-full bg-[#0D47A1] text-white py-4 rounded-xl font-bold shadow-lg active:bg-[#0A3780] transition-colors flex items-center justify-center gap-2"
              >
                <Eye className="w-5 h-5" />
                View Map
              </button>

              <p className="text-xs text-gray-500 mt-4">
                Tap to view your current location on the map
              </p>
            </div>
          </div>
        ) : (
          /* Map View */
          <>
            {/* Simulated map grid */}
            <div className="absolute inset-0 opacity-10">
              <div className="w-full h-full" style={{
                backgroundImage: `
                  linear-gradient(to right, #0D47A1 1px, transparent 1px),
                  linear-gradient(to bottom, #0D47A1 1px, transparent 1px)
                `,
                backgroundSize: '40px 40px'
              }}></div>
            </div>

            {/* Map markers and paths */}
            <div className="absolute inset-0 flex items-center justify-center">
              {/* Your location marker */}
              <div className="relative">
                <div className="absolute -inset-12 bg-blue-500/20 rounded-full animate-ping"></div>
                <div className="relative bg-[#DC143C] text-white p-4 rounded-full shadow-2xl">
                  <MapPin className="w-8 h-8" fill="white" />
                </div>
                <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 bg-white px-4 py-2 rounded-full shadow-lg whitespace-nowrap">
                  <span className="text-sm font-bold text-gray-800">Your Location</span>
                </div>
              </div>

              {/* Helper icons around */}
              <div className="absolute top-1/4 left-1/4">
                <div className="bg-[#0D47A1] text-white p-2 rounded-full shadow-lg">
                  <Shield className="w-5 h-5" />
                </div>
              </div>
              <div className="absolute bottom-1/4 right-1/4">
                <div className="bg-green-600 text-white p-2 rounded-full shadow-lg">
                  <Users className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Hide Map button */}
            <div className="absolute top-4 right-4">
              <button
                onClick={() => setShowMap(false)}
                className="bg-white text-gray-800 px-4 py-3 rounded-xl font-bold shadow-lg active:bg-gray-100 transition-colors flex items-center gap-2"
              >
                <EyeOff className="w-5 h-5" />
                Hide Map
              </button>
            </div>

            {/* Status banner */}
            <div className="absolute top-4 left-4 right-20">
              {isSharing ? (
                <div className="bg-green-600 text-white px-6 py-4 rounded-2xl shadow-xl">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                    <span className="font-bold">Location Sharing Active</span>
                  </div>
                  <p className="text-sm opacity-90">
                    Sharing location with police & trusted contacts
                  </p>
                </div>
              ) : (
                <div className="bg-gray-600 text-white px-6 py-4 rounded-2xl shadow-xl">
                  <div className="flex items-center gap-3">
                    <Eye className="w-5 h-5" />
                    <span className="font-bold">Location Sharing Inactive</span>
                  </div>
                </div>
              )}
            </div>

            {/* Info cards at bottom */}
            <div className="absolute bottom-4 left-4 right-4 space-y-3">
              <div className="bg-white/95 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-[#0D47A1] flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="font-bold text-gray-800 mb-1">Your Privacy is Protected</div>
                    <p className="text-sm text-gray-600">
                      Location is only shared during emergencies and with authorized contacts
                    </p>
                  </div>
                </div>
              </div>

              {isSharing && (
                <div className="bg-white/95 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                  <div className="text-sm text-gray-600 mb-3">
                    <strong>Currently shared with:</strong>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Police (112)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>2 Trusted Contacts</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>3 Nearby Community Helpers</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Alert Nearby Helpers Button */}
              <button
                onClick={handleAlertNearbyPeople}
                className="w-full bg-[#FF6B00] text-white py-4 rounded-xl font-bold shadow-lg active:bg-[#E55A00] transition-colors flex items-center justify-center gap-3"
              >
                <Radio className="w-6 h-6" />
                <div className="text-left">
                  <div className="font-bold">Alert Nearby Helpers</div>
                  <div className="text-xs opacity-90">Send SOS to people within 100m</div>
                </div>
                <Users className="w-5 h-5 opacity-80" />
              </button>

              {isSharing && (
                <button
                  onClick={handleStopSharingClick}
                  className="w-full bg-[#DC143C] text-white py-4 rounded-xl font-bold shadow-lg active:bg-[#B81030] transition-colors flex items-center justify-center gap-2"
                >
                  <Lock className="w-5 h-5" />
                  Stop Sharing (PIN Required)
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {/* PIN Dialog */}
      {showPinDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-6 max-w-[428px] mx-auto">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="text-center mb-6">
              <Lock className="w-12 h-12 text-[#0D47A1] mx-auto mb-3" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">Enter PIN</h3>
              <p className="text-sm text-gray-600">
                Enter your safety PIN to stop location sharing
              </p>
            </div>

            <input
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Enter 4-digit PIN"
              className="w-full px-4 py-4 border-2 border-gray-300 rounded-xl text-center text-2xl font-mono tracking-widest mb-6 focus:border-[#0D47A1] focus:outline-none"
              autoFocus
            />

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowPinDialog(false);
                  setPin('');
                }}
                className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-xl font-bold active:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handlePinSubmit}
                className="flex-1 bg-[#0D47A1] text-white py-3 rounded-xl font-bold active:bg-[#0A3780] transition-colors"
              >
                Confirm
              </button>
            </div>

            <p className="text-xs text-gray-500 text-center mt-4">
              Demo PIN: 1234
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
