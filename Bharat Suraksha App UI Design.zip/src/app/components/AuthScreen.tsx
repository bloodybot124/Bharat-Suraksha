import { useState } from 'react';
import { Shield, Phone, Lock, CheckCircle, Languages, X } from 'lucide-react';
import { LANGUAGES, getTranslation, type Language } from '@/app/translations';

interface AuthScreenProps {
  onAuthSuccess: () => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
}

export function AuthScreen({ onAuthSuccess, currentLanguage, onLanguageChange }: AuthScreenProps) {
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  
  const t = getTranslation(currentLanguage.code);

  const handlePhoneSubmit = () => {
    if (phoneNumber.length === 10) {
      setLoading(true);
      // Simulate OTP sending
      setTimeout(() => {
        setLoading(false);
        setStep('otp');
      }, 1500);
    } else {
      alert('Please enter a valid 10-digit mobile number');
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return; // Only allow single digit
    if (!/^\d*$/.test(value)) return; // Only allow numbers

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleOtpVerify = () => {
    const otpValue = otp.join('');
    if (otpValue.length === 6) {
      setLoading(true);
      // Simulate OTP verification - in demo, accept 123456
      setTimeout(() => {
        setLoading(false);
        if (otpValue === '123456') {
          onAuthSuccess();
        } else {
          alert('Invalid OTP. Demo OTP is 123456');
          setOtp(['', '', '', '', '', '']);
          document.getElementById('otp-0')?.focus();
        }
      }, 1500);
    } else {
      alert('Please enter complete 6-digit OTP');
    }
  };

  const handleEmergencyAccess = () => {
    if (confirm(`⚠️ ${t.emergencyAccess}\n\n${t.emergencyAccessDesc}\n\nContinue without login?`)) {
      onAuthSuccess();
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#0D47A1] to-[#1565C0]">
      {/* Header */}
      <div className="text-white px-6 py-8 text-center relative">
        {/* Language selector button - top right */}
        <button
          onClick={() => setShowLanguageModal(true)}
          className="absolute top-6 right-6 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full p-3 transition-colors active:scale-95"
          aria-label="Select Language"
        >
          <Languages className="w-6 h-6 text-white" />
        </button>

        <div className="bg-white/20 backdrop-blur-sm w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-12 h-12 text-white" strokeWidth={2.5} />
        </div>
        <div className="text-sm opacity-90 mb-1">भारत सुरक्षा</div>
        <h1 className="text-3xl font-bold mb-2">{t.appName}</h1>
        <p className="text-sm opacity-90">{t.appTagline}</p>
        <div className="mt-2 text-xs opacity-75">
          {t.language}: {currentLanguage.native}
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 bg-white rounded-t-[32px] px-6 py-8 overflow-y-auto">
        {step === 'phone' ? (
          <>
            {/* Phone Number Step */}
            <div className="text-center mb-8">
              <Phone className="w-12 h-12 text-[#0D47A1] mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                {t.welcomeBack}
              </h2>
              <p className="text-gray-600">
                {t.enterMobile}
              </p>
            </div>

            {/* Phone input */}
            <div className="mb-6">
              <label className="block text-sm font-bold text-gray-700 mb-2">
                {t.mobileNumber}
              </label>
              <div className="flex gap-2">
                <div className="bg-gray-100 border-2 border-gray-300 rounded-xl px-4 py-4 flex items-center justify-center">
                  <span className="font-bold text-gray-700">+91</span>
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="flex-1 px-4 py-4 border-2 border-gray-300 rounded-xl text-lg focus:border-[#0D47A1] focus:outline-none"
                  autoFocus
                />
              </div>
            </div>

            {/* Send OTP button */}
            <button
              onClick={handlePhoneSubmit}
              disabled={loading || phoneNumber.length !== 10}
              className={`w-full py-5 rounded-2xl font-bold text-white shadow-lg transition-all mb-4 ${
                loading || phoneNumber.length !== 10
                  ? 'bg-gray-300 text-gray-500'
                  : 'bg-[#0D47A1] active:bg-[#0A3780] active:scale-95'
              }`}
            >
              {loading ? t.sendingOTP : t.sendOTP}
            </button>

            {/* Security note */}
            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4 mb-6">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-green-800">
                    <strong>{t.otpSecure}</strong> {currentLanguage.code === 'en' ? 'No password required. Your mobile number is protected and never shared.' : ''}
                  </p>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* OTP Verification Step */}
            <div className="text-center mb-8">
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                {t.enterOTP}
              </h2>
              <p className="text-gray-600 mb-1">
                {t.otpSent}
              </p>
              <p className="font-bold text-gray-800">+91 {phoneNumber}</p>
            </div>

            {/* OTP input boxes */}
            <div className="mb-6">
              <label className="block text-sm font-bold text-gray-700 mb-3">
                {t.digitOTP}
              </label>
              <div className="flex gap-2 justify-center">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    id={`otp-${index}`}
                    type="tel"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Backspace' && !digit && index > 0) {
                        const prevInput = document.getElementById(`otp-${index - 1}`);
                        prevInput?.focus();
                      }
                    }}
                    className="w-12 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl focus:border-[#0D47A1] focus:outline-none"
                  />
                ))}
              </div>
            </div>

            {/* Verify button */}
            <button
              onClick={handleOtpVerify}
              disabled={loading || otp.join('').length !== 6}
              className={`w-full py-5 rounded-2xl font-bold text-white shadow-lg transition-all mb-4 ${
                loading || otp.join('').length !== 6
                  ? 'bg-gray-300 text-gray-500'
                  : 'bg-green-600 active:bg-green-700 active:scale-95'
              }`}
            >
              {loading ? t.verifying : t.verifyOTP}
            </button>

            {/* Resend OTP */}
            <button
              onClick={() => {
                setStep('phone');
                setOtp(['', '', '', '', '', '']);
              }}
              className="w-full text-[#0D47A1] font-bold py-3 active:opacity-70 transition-opacity"
            >
              {t.changeNumber}
            </button>

            {/* Demo OTP note */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 mt-6">
              <p className="text-xs text-blue-800 text-center">
                <strong>{t.demoOTP}:</strong> <span className="font-mono font-bold">123456</span>
              </p>
            </div>
          </>
        )}

        {/* Emergency access button */}
        <div className="mt-8 pt-6 border-t-2 border-gray-200">
          <button
            onClick={handleEmergencyAccess}
            className="w-full bg-[#DC143C] text-white py-5 rounded-2xl font-bold shadow-lg active:bg-[#B81030] transition-colors flex items-center justify-center gap-2"
          >
            <Shield className="w-5 h-5" />
            {t.emergencyAccess}
          </button>
          <p className="text-xs text-gray-500 text-center mt-3">
            {t.skipLogin}
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white px-6 py-4 text-center border-t border-gray-200">
        <p className="text-xs text-gray-500">
          {t.protectedBy}
        </p>
      </div>

      {/* Language Selection Modal */}
      {showLanguageModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
          <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[80vh] flex flex-col animate-slide-up">
            {/* Modal header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200">
              <h3 className="text-xl font-bold text-gray-800">{t.selectLanguage}</h3>
              <button
                onClick={() => setShowLanguageModal(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                aria-label="Close"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>

            {/* Language list - scrollable */}
            <div className="overflow-y-auto flex-1 px-4 py-4">
              <div className="space-y-2">
                {LANGUAGES.map((language) => (
                  <button
                    key={language.code}
                    onClick={() => {
                      onLanguageChange(language);
                      setShowLanguageModal(false);
                    }}
                    className={`w-full text-left px-4 py-4 rounded-xl transition-all ${
                      currentLanguage.code === language.code
                        ? 'bg-[#0D47A1] text-white shadow-md'
                        : 'bg-gray-50 hover:bg-gray-100 text-gray-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-bold">{language.name}</div>
                        <div className={`text-sm ${
                          currentLanguage.code === language.code
                            ? 'text-white/90'
                            : 'text-gray-600'
                        }`}>
                          {language.native}
                        </div>
                      </div>
                      {currentLanguage.code === language.code && (
                        <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                          <div className="w-3 h-3 bg-[#0D47A1] rounded-full"></div>
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Modal footer */}
            <div className="px-6 py-4 border-t border-gray-200">
              <button
                onClick={() => setShowLanguageModal(false)}
                className="w-full bg-gray-200 text-gray-800 py-3 rounded-xl font-bold hover:bg-gray-300 transition-colors"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
