import { Home, MapPin, AlertTriangle, Users, Settings } from 'lucide-react';
import type { Screen } from '@/app/App';
import type { Translations } from '@/app/translations';

interface BottomNavigationProps {
  currentScreen: Screen;
  onNavigate: (screen: Screen) => void;
  t: Translations;
}

export function BottomNavigation({ currentScreen, onNavigate, t }: BottomNavigationProps) {
  const navItems = [
    { id: 'home' as Screen, icon: Home, label: t.home },
    { id: 'location' as Screen, icon: MapPin, label: t.location },
    { id: 'proximity' as Screen, icon: AlertTriangle, label: t.proximity },
    { id: 'contacts' as Screen, icon: Users, label: t.contacts },
    { id: 'settings' as Screen, icon: Settings, label: t.settings },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-[428px] mx-auto bg-white border-t-2 border-gray-200 shadow-lg z-40">
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center py-2 px-3 rounded-xl transition-colors min-w-[60px] ${
                isActive 
                  ? 'bg-[#0D47A1] text-white' 
                  : 'text-gray-600 active:bg-gray-100'
              }`}
            >
              <Icon className={`w-6 h-6 mb-1 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              <span className={`text-xs ${isActive ? 'font-bold' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
