import { useState, useEffect } from 'react';
import { AlertTriangle, Shield, Phone, X } from 'lucide-react';
import type { Translations } from '@/app/translations';

interface EmergencyActiveScreenProps {
  startTime: number;
  onCancel: () => void;
  t: Translations;
}

export function EmergencyActiveScreen({ startTime, onCancel, t }: EmergencyActiveScreenProps) {
  const [elapsedTime, setElapsedTime] = useState(0);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [blink, setBlink] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlink(prev => !prev);
    }, 500);

    return () => clearInterval(blinkInterval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCancelClick = () => {
    setShowCancelConfirm(true);
  };

  const handleConfirmCancel = () => {
    onCancel();
  };

  return (
    <div className="fixed inset-0 bg-[#DC143C] z-50 flex flex-col items-center justify-center max-w-[428px] mx-auto">
      {/* Alert indicator */}
      <div className="absolute top-0 left-0 right-0 bg-white py-3">
        <div className="flex items-center justify-center gap-2">
          <div className={`w-3 h-3 rounded-full bg-[#DC143C] transition-opacity ${blink ? 'opacity-100' : 'opacity-30'}`}></div>
          <span className="text-[#DC143C] font-bold">EMERGENCY ACTIVE</span>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center text-white">
        <div className={`mb-8 transition-opacity ${blink ? 'opacity-100' : 'opacity-70'}`}>
          <AlertTriangle className="w-32 h-32 mx-auto" strokeWidth={2.5} />
        </div>

        <h1 className="text-3xl font-bold mb-2">Emergency Active</h1>
        <p className="text-xl mb-8">Help is being notified</p>

        {/* Privacy Shield Banner */}
        <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-5 mb-8 w-full max-w-sm border-2 border-white/30">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Shield className="w-6 h-6" />
            <span className="font-bold text-lg">Your Privacy Protected</span>
          </div>
          <p className="text-sm opacity-95">
            Your exact location is hidden from the public. Only shared with police and your trusted contacts.
          </p>
        </div>

        <p className="text-lg opacity-90 mb-6 max-w-sm">
          Emergency alert sent to:
        </p>

        {/* Recipients list */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 mb-8 w-full max-w-sm">
          <div className="space-y-3 text-left">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5" />
              <span>Police (112)</span>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5" />
              <span>Trusted Contacts (2)</span>
            </div>
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5" />
              <span>Nearby Helpers</span>
            </div>
          </div>
        </div>

        {/* Timer */}
        <div className="text-6xl font-bold mb-4 font-mono">
          {formatTime(elapsedTime)}
        </div>
        <p className="text-lg opacity-90 mb-12">Emergency Duration</p>

        {/* Reassurance message */}
        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-6 max-w-sm">
          <p className="text-base">
            <strong>Stay calm.</strong> Help has been alerted. Your location is being shared continuously. Keep your phone with you.
          </p>
        </div>
      </div>

      {/* Cancel button */}
      <div className="absolute bottom-8 left-0 right-0 px-8">
        {!showCancelConfirm ? (
          <button
            onClick={handleCancelClick}
            className="w-full bg-white text-[#DC143C] py-5 rounded-2xl font-bold shadow-xl active:bg-gray-100 transition-colors"
          >
            I'm Safe - Cancel Alert
          </button>
        ) : (
          <div className="bg-white rounded-2xl p-6 shadow-xl">
            <p className="text-gray-800 mb-4 text-center font-bold">
              Are you sure you want to cancel the emergency?
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowCancelConfirm(false)}
                className="flex-1 bg-gray-200 text-gray-800 py-4 rounded-xl font-bold active:bg-gray-300 transition-colors"
              >
                No, Keep Active
              </button>
              <button
                onClick={handleConfirmCancel}
                className="flex-1 bg-[#DC143C] text-white py-4 rounded-xl font-bold active:bg-[#B81030] transition-colors"
              >
                Yes, I'm Safe
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
