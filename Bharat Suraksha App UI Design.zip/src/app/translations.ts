// Translation data for Bharat Suraksha app
export type LanguageCode = 'en' | 'hi' | 'ta' | 'te' | 'bn' | 'gu' | 'kn' | 'ml' | 'mr' | 'pa' | 'ur';

export interface Language {
  code: LanguageCode | string;
  name: string;
  native: string;
}

export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English', native: 'English' },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা' },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം' },
  { code: 'mr', name: 'Marathi', native: 'मराठी' },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { code: 'ur', name: 'Urdu', native: 'اردو' },
  { code: 'as', name: 'Assamese', native: 'অসমীয়া' },
  { code: 'brx', name: 'Bodo', native: 'बड़ो' },
  { code: 'doi', name: 'Dogri', native: 'डोगरी' },
  { code: 'ks', name: 'Kashmiri', native: 'कॉशुर' },
  { code: 'kok', name: 'Konkani', native: 'कोंकणी' },
  { code: 'mai', name: 'Maithili', native: 'मैथिली' },
  { code: 'mni', name: 'Manipuri', native: 'মৈতৈলোন্' },
  { code: 'ne', name: 'Nepali', native: 'नेपाली' },
  { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ' },
  { code: 'sa', name: 'Sanskrit', native: 'संस्कृतम्' },
  { code: 'sat', name: 'Santali', native: 'ᱥᱟᱱᱛᱟᱲᱤ' },
  { code: 'sd', name: 'Sindhi', native: 'सिन्धी' },
];

export interface Translations {
  // App name
  appName: string;
  appTagline: string;
  
  // Auth Screen
  welcomeBack: string;
  enterMobile: string;
  mobileNumber: string;
  sendOTP: string;
  sendingOTP: string;
  otpSecure: string;
  enterOTP: string;
  otpSent: string;
  digitOTP: string;
  verifyOTP: string;
  verifying: string;
  changeNumber: string;
  emergencyAccess: string;
  skipLogin: string;
  emergencyAccessDesc: string;
  demoOTP: string;
  protectedBy: string;
  selectLanguage: string;
  language: string;
  close: string;
  
  // Home Screen
  youAreProtected: string;
  pressSOS: string;
  privacyProtected: string;
  privacyMessage: string;
  emergencyContacts: string;
  callPolice: string;
  policeEmergency: string;
  callChildline: string;
  childline: string;
  callWomenHelpline: string;
  womenHelpline: string;
  sosEmergency: string;
  tapToActivate: string;
  safe: string;
  
  // Bottom Navigation
  home: string;
  location: string;
  proximity: string;
  contacts: string;
  settings: string;
  
  // Emergency Active Screen
  emergencyActive: string;
  alertSent: string;
  sharingLocation: string;
  elapsedTime: string;
  cancelEmergency: string;
  confirmCancel: string;
  
  // Location Sharing Screen
  liveLocation: string;
  locationSharing: string;
  stopSharing: string;
  shareWith: string;
  yourLocation: string;
  accuracyHigh: string;
  
  // Proximity Alert Screen
  proximityAlerts: string;
  communityAlerts: string;
  recentAlerts: string;
  noAlerts: string;
  viewMap: string;
  away: string;
  
  // Trusted Contacts Screen
  trustedContacts: string;
  addContact: string;
  autoAlert: string;
  remove: string;
  name: string;
  phone: string;
  relation: string;
  save: string;
  cancel: string;
  
  // Settings Screen
  settingsPrivacy: string;
  privacyControls: string;
  otpLogin: string;
  otpLoginDesc: string;
  currentNumber: string;
  dataPrivacy: string;
  locationControl: string;
  locationControlDesc: string;
  communityAlertsToggle: string;
  communityAlertsDesc: string;
  dataRetention: string;
  days30: string;
  days90: string;
  year1: string;
  legalCompliance: string;
  legalDesc: string;
  accountSecurity: string;
  logout: string;
}

export const translations: Record<string, Translations> = {
  en: {
    appName: 'Bharat Suraksha',
    appTagline: 'Community-Assisted Emergency Response',
    welcomeBack: 'Welcome Back',
    enterMobile: 'Enter your mobile number to continue',
    mobileNumber: 'Mobile Number',
    sendOTP: 'Send OTP',
    sendingOTP: 'Sending OTP...',
    otpSecure: 'OTP login is secure.',
    enterOTP: 'Enter OTP',
    otpSent: "We've sent a 6-digit code to",
    digitOTP: '6-Digit OTP',
    verifyOTP: 'Verify OTP',
    verifying: 'Verifying...',
    changeNumber: 'Change Number',
    emergencyAccess: 'Emergency Access (Skip Login)',
    skipLogin: 'For immediate emergencies, you can use the app without logging in',
    emergencyAccessDesc: 'You can use the app without logging in for emergency situations.',
    demoOTP: 'Demo Mode: Use OTP',
    protectedBy: 'Protected by Government of India • Secure & Private',
    selectLanguage: 'Select Language',
    language: 'Language',
    close: 'Close',
    youAreProtected: 'You are Protected',
    pressSOS: 'Press SOS if you need help',
    privacyProtected: 'Your privacy is protected.',
    privacyMessage: 'Location is shared only during emergencies.',
    emergencyContacts: 'EMERGENCY CONTACTS',
    callPolice: 'Call 100',
    policeEmergency: 'Police Emergency',
    callChildline: 'Call 1098',
    childline: 'Childline',
    callWomenHelpline: 'Call 181 / 1091',
    womenHelpline: 'Women Helpline',
    sosEmergency: 'EMERGENCY',
    tapToActivate: 'Tap to activate emergency alert',
    safe: 'Safe',
    home: 'Home',
    location: 'Location',
    proximity: 'Proximity',
    contacts: 'Contacts',
    settings: 'Settings',
    emergencyActive: 'EMERGENCY ACTIVE',
    alertSent: 'Alert sent to trusted contacts',
    sharingLocation: 'Sharing your live location',
    elapsedTime: 'Elapsed Time',
    cancelEmergency: 'Cancel Emergency',
    confirmCancel: 'Are you sure you want to cancel the emergency alert?',
    liveLocation: 'Live Location Sharing',
    locationSharing: 'Location sharing is active',
    stopSharing: 'Stop Sharing',
    shareWith: 'Sharing with',
    yourLocation: 'Your Location',
    accuracyHigh: 'Accuracy: High',
    proximityAlerts: 'Proximity Alerts',
    communityAlerts: 'Community safety alerts in your area',
    recentAlerts: 'Recent Alerts',
    noAlerts: 'No recent alerts in your area',
    viewMap: 'View on Map',
    away: 'away',
    trustedContacts: 'Trusted Contacts',
    addContact: 'Add Contact',
    autoAlert: 'Auto-alert on SOS',
    remove: 'Remove',
    name: 'Name',
    phone: 'Phone Number',
    relation: 'Relation',
    save: 'Save Contact',
    cancel: 'Cancel',
    settingsPrivacy: 'Settings & Privacy',
    privacyControls: 'Privacy Controls',
    otpLogin: 'OTP Login Details',
    otpLoginDesc: 'Your account is secured with mobile OTP verification. No password is required or stored.',
    currentNumber: 'Current Number',
    dataPrivacy: 'Data & Privacy',
    locationControl: 'Location Sharing',
    locationControlDesc: 'You control when your location is shared',
    communityAlertsToggle: 'Community Alerts',
    communityAlertsDesc: 'Receive anonymous safety alerts nearby',
    dataRetention: 'Data Retention Period',
    days30: '30 Days',
    days90: '90 Days',
    year1: '1 Year',
    legalCompliance: 'Legal & Compliance',
    legalDesc: 'This app complies with Indian privacy laws and data protection standards.',
    accountSecurity: 'Account & Security',
    logout: 'Logout',
  },
  hi: {
    appName: 'भारत सुरक्षा',
    appTagline: 'सामुदायिक सहायता आपातकालीन प्रतिक्रिया',
    welcomeBack: 'वापस आपका स्वागत है',
    enterMobile: 'जारी रखने के लिए अपना मोबाइल नंबर दर्ज करें',
    mobileNumber: 'मोबाइल नंबर',
    sendOTP: 'OTP भेजें',
    sendingOTP: 'OTP भेजा जा रहा है...',
    otpSecure: 'OTP लॉगिन सुरक्षित है।',
    enterOTP: 'OTP दर्ज करें',
    otpSent: 'हमने 6 अंकों का कोड भेजा है',
    digitOTP: '6-अंकीय OTP',
    verifyOTP: 'OTP सत्यापित करें',
    verifying: 'सत्यापन हो रहा है...',
    changeNumber: 'नंबर बदलें',
    emergencyAccess: 'आपातकालीन एक्सेस (लॉगिन छोड़ें)',
    skipLogin: 'तत्काल आपात स्थिति के लिए, आप लॉगिन के बिना ऐप का उपयोग कर सकते हैं',
    emergencyAccessDesc: 'आप आपातकालीन स्थितियों के लिए लॉगिन के बिना ऐप का उपयोग कर सकते हैं।',
    demoOTP: 'डेमो मोड: OTP का उपयोग करें',
    protectedBy: 'भारत सरकार द्वारा संरक्षित • सुरक्षित और निजी',
    selectLanguage: 'भाषा चुनें',
    language: 'भाषा',
    close: 'बंद करें',
    youAreProtected: 'आप सुरक्षित हैं',
    pressSOS: 'मदद की ज़रूरत हो तो SOS दबाएं',
    privacyProtected: 'आपकी गोपनीयता सुरक्षित है।',
    privacyMessage: 'स्थान केवल आपात स्थिति में साझा किया जाता है।',
    emergencyContacts: 'आपातकालीन संपर्क',
    callPolice: '100 पर कॉल करें',
    policeEmergency: 'पुलिस आपातकाल',
    callChildline: '1098 पर कॉल करें',
    childline: 'चाइल्डलाइन',
    callWomenHelpline: '181 / 1091 पर कॉल करें',
    womenHelpline: 'महिला हेल्पलाइन',
    sosEmergency: 'आपातकाल',
    tapToActivate: 'आपातकालीन अलर्ट सक्रिय करने के लिए टैप करें',
    safe: 'सुरक्षित',
    home: 'होम',
    location: 'स्थान',
    proximity: 'निकटता',
    contacts: 'संपर्क',
    settings: 'सेटिंग्स',
    emergencyActive: 'आपातकाल सक्रिय',
    alertSent: 'विश्वसनीय संपर्कों को अलर्ट भेजा गया',
    sharingLocation: 'आपका लाइव स्थान साझा किया जा रहा है',
    elapsedTime: 'बीता हुआ समय',
    cancelEmergency: 'आपातकाल रद्द करें',
    confirmCancel: 'क्या आप निश्चित हैं कि आप आपातकालीन अलर्ट रद्द करना चाहते हैं?',
    liveLocation: 'लाइव स्थान साझाकरण',
    locationSharing: 'स्थान साझाकरण सक्रिय है',
    stopSharing: 'साझा करना बंद करें',
    shareWith: 'के साथ साझा करना',
    yourLocation: 'आपका स्थान',
    accuracyHigh: 'सटीकता: उच्च',
    proximityAlerts: 'निकटता अलर्ट',
    communityAlerts: 'आपके क्षेत्र में सामुदायिक सुरक्षा अलर्ट',
    recentAlerts: 'हाल के अलर्ट',
    noAlerts: 'आपके क्षेत्र में कोई हालिया अलर्ट नहीं',
    viewMap: 'मानचित्र पर देखें',
    away: 'दूर',
    trustedContacts: 'विश्वसनीय संपर्क',
    addContact: 'संपर्क जोड़ें',
    autoAlert: 'SOS पर ऑटो-अलर्ट',
    remove: 'हटाएं',
    name: 'नाम',
    phone: 'फोन नंबर',
    relation: 'संबंध',
    save: 'संपर्क सहेजें',
    cancel: 'रद्द करें',
    settingsPrivacy: 'सेटिंग्स और गोपनीयता',
    privacyControls: 'गोपनीयता नियंत्रण',
    otpLogin: 'OTP लॉगिन विवरण',
    otpLoginDesc: 'आपका खाता मोबाइल OTP सत्यापन से सुरक्षित है। कोई पासवर्ड आवश्यक या संग्रहीत नहीं है।',
    currentNumber: 'वर्तमान नंबर',
    dataPrivacy: 'डेटा और गोपनीयता',
    locationControl: 'स्थान साझाकरण',
    locationControlDesc: 'आप नियंत्रित करते हैं कि आपका स्थान कब साझा किया जाता है',
    communityAlertsToggle: 'सामुदायिक अलर्ट',
    communityAlertsDesc: 'पास में गुमनाम सुरक्षा अलर्ट प्राप्त करें',
    dataRetention: 'डेटा प्रतिधारण अवधि',
    days30: '30 दिन',
    days90: '90 दिन',
    year1: '1 वर्ष',
    legalCompliance: 'कानूनी और अनुपालन',
    legalDesc: 'यह ऐप भारतीय गोपनीयता कानूनों और डेटा संरक्षण मानकों का अनुपालन करता है।',
    accountSecurity: 'खाता और सुरक्षा',
    logout: 'लॉगआउट',
  },
  ta: {
    appName: 'பாரத சுரக்ஷா',
    appTagline: 'சமூக உதவி அவசர பதில்',
    welcomeBack: 'மீண்டும் வரவேற்கிறோம்',
    enterMobile: 'தொடர உங்கள் மொபைல் எண்ணை உள்ளிடவும்',
    mobileNumber: 'மொபைல் எண்',
    sendOTP: 'OTP அனுப்பு',
    sendingOTP: 'OTP அனுப்பப்படுகிறது...',
    otpSecure: 'OTP உள்நுழைவு பாதுகாப்பானது.',
    enterOTP: 'OTP உள்ளிடவும்',
    otpSent: 'நாங்கள் 6 இலக்க குறியீட்டை அனுப்பியுள்ளோம்',
    digitOTP: '6-இலக்க OTP',
    verifyOTP: 'OTP சரிபார்க்கவும்',
    verifying: 'சரிபார்க்கப்படுகிறது...',
    changeNumber: 'எண்ணை மாற்று',
    emergencyAccess: 'அவசர அணுகல் (உள்நுழைவைத் தவிர்க்கவும்)',
    skipLogin: 'உடனடி அவசரநிலைகளுக்கு, உள்நுழையாமல் பயன்பாட்டைப் பயன்படுத்தலாம்',
    emergencyAccessDesc: 'அவசரநிலைகளுக்கு உள்நுழையாமல் பயன்பாட்டைப் பயன்படுத்தலாம்.',
    demoOTP: 'டெமோ பயன்முறை: OTP பயன்படுத்தவும்',
    protectedBy: 'இந்திய அரசால் பாதுகாக்கப்பட்டது • பாதுகாப்பான மற்றும் தனிப்பட்டது',
    selectLanguage: 'மொழியைத் தேர்ந்தெடுக்கவும்',
    language: 'மொழி',
    close: 'மூடு',
    youAreProtected: 'நீங்கள் பாதுகாக்கப்பட்டுள்ளீர்கள்',
    pressSOS: 'உதவி தேவைப்பட்டால் SOS அழுத்தவும்',
    privacyProtected: 'உங்கள் தனியுரிமை பாதுகாக்கப்படுகிறது.',
    privacyMessage: 'இடம் அவசரநிலைகளில் மட்டுமே பகிரப்படுகிறது.',
    emergencyContacts: 'அவசர தொடர்புகள்',
    callPolice: '100 அழைக்கவும்',
    policeEmergency: 'காவல்துறை அவசரம்',
    callChildline: '1098 அழைக்கவும்',
    childline: 'சைல்டுலைன்',
    callWomenHelpline: '181 / 1091 அழைக்கவும்',
    womenHelpline: 'மகளிர் உதவி எண்',
    sosEmergency: 'அவசரம்',
    tapToActivate: 'அவசர எச்சரிக்கையை செயல்படுத்த தட்டவும்',
    safe: 'பாதுகாப்பானது',
    home: 'முகப்பு',
    location: 'இடம்',
    proximity: 'அருகாமை',
    contacts: 'தொடர்புகள்',
    settings: 'அமைப்புகள்',
    emergencyActive: 'அவசரம் செயலில்',
    alertSent: 'நம்பகமான தொடர்புகளுக்கு எச்சரிக்கை அனுப்பப்பட்டது',
    sharingLocation: 'உங்கள் நேரடி இடம் பகிரப்படுகிறது',
    elapsedTime: 'கழிந்த நேரம்',
    cancelEmergency: 'அவசரத்தை ரத்து செய்',
    confirmCancel: 'அவசர எச்சரிக்கையை ரத்து செய்ய விரும்புகிறீர்களா?',
    liveLocation: 'நேரடி இட பகிர்வு',
    locationSharing: 'இட பகிர்வு செயலில் உள்ளது',
    stopSharing: 'பகிர்வதை நிறுத்து',
    shareWith: 'உடன் பகிர்தல்',
    yourLocation: 'உங்கள் இடம்',
    accuracyHigh: 'துல்லியம்: அதிகம்',
    proximityAlerts: 'அருகாமை எச்சரிக்கைகள்',
    communityAlerts: 'உங்கள் பகுதியில் சமூக பாதுகாப்பு எச்சரிக்கைகள்',
    recentAlerts: 'சமீபத்திய எச்சரிக்கைகள்',
    noAlerts: 'உங்கள் பகுதியில் சமீபத்திய எச்சரிக்கைகள் இல்லை',
    viewMap: 'வரைபடத்தில் பார்க்கவும்',
    away: 'தூரம்',
    trustedContacts: 'நம்பகமான தொடர்புகள்',
    addContact: 'தொடர்பைச் சேர்க்கவும்',
    autoAlert: 'SOS இல் தானியங்கு-எச்சரிக்கை',
    remove: 'அகற்று',
    name: 'பெயர்',
    phone: 'தொலைபேசி எண்',
    relation: 'உறவு',
    save: 'தொடர்பைச் சேமி',
    cancel: 'ரத்து செய்',
    settingsPrivacy: 'அமைப்புகள் மற்றும் தனியுரிமை',
    privacyControls: 'தனியுரிமை கட்டுப்பாடுகள்',
    otpLogin: 'OTP உள்நுழைவு விவரங்கள்',
    otpLoginDesc: 'உங்கள் கணக்கு மொபைல் OTP சரிபார்ப்புடன் பாதுகாக்கப்படுகிறது. கடவுச்சொல் தேவையில்லை அல்லது சேமிக்கப்படவில்லை.',
    currentNumber: 'தற்போதைய எண்',
    dataPrivacy: 'தரவு மற்றும் தனியுரிமை',
    locationControl: 'இட பகிர்வு',
    locationControlDesc: 'உங்கள் இடம் எப்போது பகிரப்படுகிறது என்பதை நீங்கள் கட்டுப்படுத்துகிறீர்கள்',
    communityAlertsToggle: 'சமூக எச்சரிக்கைகள்',
    communityAlertsDesc: 'அருகில் அநாமதேய பாதுகாப்பு எச்சரிக்கைகளைப் பெறுங்கள்',
    dataRetention: 'தரவு வைத்திருத்தல் காலம்',
    days30: '30 நாட்கள்',
    days90: '90 நாட்கள்',
    year1: '1 வருடம்',
    legalCompliance: 'சட்ட மற்றும் இணக்கம்',
    legalDesc: 'இந்த பயன்பாடு இந்திய தனியுரிமை சட்டங்கள் மற்றும் தரவு பாதுகாப்பு தரங்களுக்கு இணங்குகிறது.',
    accountSecurity: 'கணக்கு மற்றும் பாதுகாப்பு',
    logout: 'வெளியேறு',
  },
  te: {
    appName: 'భారత్ సురక్ష',
    appTagline: 'కమ్యూనిటీ-సహాయ అత్యవసర ప్రతిస్పందన',
    welcomeBack: 'తిరిగి స్వాగతం',
    enterMobile: 'కొనసాగించడానికి మీ మొబైల్ నంబర్‌ను నమోదు చేయండి',
    mobileNumber: 'మొబైల్ నంబర్',
    sendOTP: 'OTP పంపండి',
    sendingOTP: 'OTP పంపుతోంది...',
    otpSecure: 'OTP లాగిన్ సురక్షితం.',
    enterOTP: 'OTP నమోదు చేయండి',
    otpSent: 'మేము 6-అంకెల కోడ్‌ను పంపాము',
    digitOTP: '6-అంకెల OTP',
    verifyOTP: 'OTP ధృవీకరించండి',
    verifying: 'ధృవీకరిస్తోంది...',
    changeNumber: 'నంబర్ మార్చండి',
    emergencyAccess: 'అత్యవసర ప్రవేశం (లాగిన్ దాటవేయండి)',
    skipLogin: 'తక్షణ అత్యవసర పరిస్థితుల కోసం, లాగిన్ చేయకుండా యాప్‌ను ఉపయోగించవచ్చు',
    emergencyAccessDesc: 'అత్యవసర పరిస్థితుల కోసం లాగిన్ చేయకుండా యాప్‌ను ఉపయోగించవచ్చు.',
    demoOTP: 'డెమో మోడ్: OTP ఉపయోగించండి',
    protectedBy: 'భారత ప్రభుత్వంచే రక్షించబడింది • సురక్షితం & ప్రైవేట్',
    selectLanguage: 'భాషను ఎంచుకోండి',
    language: 'భాష',
    close: 'మూసివేయండి',
    youAreProtected: 'మీరు రక్షించబడ్డారు',
    pressSOS: 'సహాయం కావాలంటే SOS నొక్కండి',
    privacyProtected: 'మీ గోప్యత రక్షించబడింది.',
    privacyMessage: 'స్థానం అత్యవసర పరిస్థితుల్లో మాత్రమే భాగస్వామ్యం చేయబడుతుంది.',
    emergencyContacts: 'అత్యవసర పరిచయాలు',
    callPolice: '100 కాల్ చేయండి',
    policeEmergency: 'పోలీస్ అత్యవసరం',
    callChildline: '1098 కాల్ చేయండి',
    childline: 'చైల్డ్‌లైన్',
    callWomenHelpline: '181 / 1091 కాల్ చేయండి',
    womenHelpline: 'మహిళా సహాయవాణి',
    sosEmergency: 'అత్యవసరం',
    tapToActivate: 'అత్యవసర హెచ్చరికను సక్రియం చేయడానికి నొక్కండి',
    safe: 'సురక్షితం',
    home: 'హోమ్',
    location: 'స్థానం',
    proximity: 'సామీప్యత',
    contacts: 'పరిచయాలు',
    settings: 'సెట్టింగ్‌లు',
    emergencyActive: 'అత్యవసరం సక్రియం',
    alertSent: 'విశ్వసనీయ పరిచయాలకు హెచ్చరిక పంపబడింది',
    sharingLocation: 'మీ లైవ్ స్థానం భాగస్వామ్యం చేయబడుతోంది',
    elapsedTime: 'గడచిన సమయం',
    cancelEmergency: 'అత్యవసరాన్ని రద్దు చేయండి',
    confirmCancel: 'అత్యవసర హెచ్చరికను రద్దు చేయాలనుకుంటున్నారా?',
    liveLocation: 'లైవ్ స్థాన భాగస్వామ్యం',
    locationSharing: 'స్థాన భాగస్వామ్యం సక్రియంగా ఉంది',
    stopSharing: 'భాగస్వామ్యం ఆపండి',
    shareWith: 'తో భాగస్వామ్యం',
    yourLocation: 'మీ స్థానం',
    accuracyHigh: 'ఖచ్చితత్వం: అధికం',
    proximityAlerts: 'సామీప్య హెచ్చరికలు',
    communityAlerts: 'మీ ప్రాంతంలో కమ్యూనిటీ భద్రతా హెచ్చరికలు',
    recentAlerts: 'ఇటీవలి హెచ్చరికలు',
    noAlerts: 'మీ ప్రాంతంలో ఇటీవలి హెచ్చరికలు లేవు',
    viewMap: 'మ్యాప్‌లో చూడండి',
    away: 'దూరం',
    trustedContacts: 'విశ్వసనీయ పరిచయాలు',
    addContact: 'పరిచయాన్ని జోడించండి',
    autoAlert: 'SOS లో ఆటో-హెచ్చరిక',
    remove: 'తొలగించండి',
    name: 'పేరు',
    phone: 'ఫోన్ నంబర్',
    relation: 'సంబంధం',
    save: 'పరిచయాన్ని సేవ్ చేయండి',
    cancel: 'రద్దు చేయండి',
    settingsPrivacy: 'సెట్టింగ్‌లు & గోప్యత',
    privacyControls: 'గోప్యత నియంత్రణలు',
    otpLogin: 'OTP లాగిన్ వివరాలు',
    otpLoginDesc: 'మీ ఖాతా మొబైల్ OTP ధృవీకరణతో సురక్షితం చేయబడింది. పాస్‌వర్డ్ అవసరం లేదు లేదా నిల్వ చేయబడదు.',
    currentNumber: 'ప్రస్తుత నంబర్',
    dataPrivacy: 'డేటా & గోప్యత',
    locationControl: 'స్థాన భాగస్వామ్యం',
    locationControlDesc: 'మీ స్థానం ఎప్పుడు భాగస్వామ్యం చేయబడుతుందో మీరు నియంత్రిస్తారు',
    communityAlertsToggle: 'కమ్యూనిటీ హెచ్చరికలు',
    communityAlertsDesc: 'సమీపంలో అనామక భద్రతా హెచ్చరికలను స్వీకరించండి',
    dataRetention: 'డేటా నిలుపుదల వ్యవధి',
    days30: '30 రోజులు',
    days90: '90 రోజులు',
    year1: '1 సంవత్సరం',
    legalCompliance: 'చట్టపరమైన & అనుగుణత',
    legalDesc: 'ఈ యాప్ భారతీయ గోప్యతా చట్టాలు మరియు డేటా రక్షణ ప్రమాణాలకు అనుగుణంగా ఉంది.',
    accountSecurity: 'ఖాతా & భద్రత',
    logout: 'లాగౌట్',
  },
  bn: {
    appName: 'ভারত সুরক্ষা',
    appTagline: 'কমিউনিটি-সহায়ক জরুরী প্রতিক্রিয়া',
    welcomeBack: 'স্বাগতম',
    enterMobile: 'চালিয়ে যেতে আপনার মোবাইল নম্বর লিখুন',
    mobileNumber: 'মোবাইল নম্বর',
    sendOTP: 'OTP পাঠান',
    sendingOTP: 'OTP পাঠানো হচ্ছে...',
    otpSecure: 'OTP লগইন নিরাপদ।',
    enterOTP: 'OTP লিখুন',
    otpSent: 'আমরা ৬-সংখ্যার কোড পাঠিয়েছি',
    digitOTP: '৬-সংখ্যার OTP',
    verifyOTP: 'OTP যাচাই করুন',
    verifying: 'যাচাই করা হচ্ছে...',
    changeNumber: 'নম্বর পরিবর্তন করুন',
    emergencyAccess: 'জরুরি অ্যাক্সেস (লগইন এড়িয়ে যান)',
    skipLogin: 'তাত্ক্ষণিক জরুরী অবস্থার জন্য, আপনি লগইন ছাড়াই অ্যাপ ব্যবহার করতে পারেন',
    emergencyAccessDesc: 'জরুরী পরিস্থিতির জন্য লগইন ছাড়াই অ্যাপ ব্যবহার করতে পারেন।',
    demoOTP: 'ডেমো মোড: OTP ব্যবহার করুন',
    protectedBy: 'ভারত সরকার দ্বারা সুরক্ষিত • নিরাপদ এবং ব্যক্তিগত',
    selectLanguage: 'ভাষা নির্বাচন করুন',
    language: 'ভাষা',
    close: 'বন্ধ করুন',
    youAreProtected: 'আপনি সুরক্ষিত',
    pressSOS: 'সাহায্য প্রয়োজন হলে SOS চাপুন',
    privacyProtected: 'আপনার গোপনীয়তা সুরক্ষিত।',
    privacyMessage: 'অবস্থান শুধুমাত্র জরুরী অবস্থায় শেয়ার করা হয়।',
    emergencyContacts: 'জরুরি যোগাযোগ',
    callPolice: '100 কল করুন',
    policeEmergency: 'পুলিশ জরুরী',
    callChildline: '1098 কল করুন',
    childline: 'চাইল্ডলাইন',
    callWomenHelpline: '181 / 1091 কল করুন',
    womenHelpline: 'মহিলা হেল্পলাইন',
    sosEmergency: 'জরুরী',
    tapToActivate: 'জরুরী সতর্কতা সক্রিয় করতে ট্যাপ করুন',
    safe: 'নিরাপদ',
    home: 'হোম',
    location: 'অবস্থান',
    proximity: 'নৈকট্য',
    contacts: 'যোগাযোগ',
    settings: 'সেটিংস',
    emergencyActive: 'জরুরী সক্রিয়',
    alertSent: 'বিশ্বস্ত পরিচিতিদের সতর্কতা পাঠানো হয়েছে',
    sharingLocation: 'আপনার লাইভ অবস্থান শেয়ার করা হচ্ছে',
    elapsedTime: 'অতিক্রান্ত সময়',
    cancelEmergency: 'জরুরী বাতিল করুন',
    confirmCancel: 'আপনি কি জরুরী সতর্কতা বাতিল করতে চান?',
    liveLocation: 'লাইভ অবস্থান শেয়ারিং',
    locationSharing: 'অবস্থান শেয়ারিং সক্রিয়',
    stopSharing: 'শেয়ারিং বন্ধ করুন',
    shareWith: 'সাথে শেয়ার করা',
    yourLocation: 'আপনার অবস্থান',
    accuracyHigh: 'নির্ভুলতা: উচ্চ',
    proximityAlerts: 'নৈকট্য সতর্কতা',
    communityAlerts: 'আপনার এলাকায় কমিউনিটি সুরক্ষা সতর্কতা',
    recentAlerts: 'সাম্প্রতিক সতর্কতা',
    noAlerts: 'আপনার এলাকায় কোন সাম্প্রতিক সতর্কতা নেই',
    viewMap: 'মানচিত্রে দেখুন',
    away: 'দূরে',
    trustedContacts: 'বিশ্বস্ত পরিচিতি',
    addContact: 'পরিচিতি যোগ করুন',
    autoAlert: 'SOS এ অটো-সতর্কতা',
    remove: 'সরান',
    name: 'নাম',
    phone: 'ফোন নম্বর',
    relation: 'সম্পর্ক',
    save: 'পরিচিতি সংরক্ষণ করুন',
    cancel: 'বাতিল করুন',
    settingsPrivacy: 'সেটিংস এবং গোপনীয়তা',
    privacyControls: 'গোপনীয়তা নিয়ন্ত্রণ',
    otpLogin: 'OTP লগইন বিবরণ',
    otpLoginDesc: 'আপনার অ্যাকাউন্ট মোবাইল OTP যাচাইকরণ দিয়ে সুরক্ষিত। কোন পাসওয়ার্ড প্রয়োজন বা সংরক্ষিত নেই।',
    currentNumber: 'বর্তমান নম্বর',
    dataPrivacy: 'ডেটা এবং গোপনীয়তা',
    locationControl: 'অবস্থান শেয়ারিং',
    locationControlDesc: 'আপনার অবস্থান কখন শেয়ার করা হয় তা আপনি নিয়ন্ত্রণ করেন',
    communityAlertsToggle: 'কমিউনিটি সতর্কতা',
    communityAlertsDesc: 'কাছাকাছি বেনামী সুরক্ষা সতর্কতা পান',
    dataRetention: 'ডেটা ধারণ সময়কাল',
    days30: '৩০ দিন',
    days90: '৯০ দিন',
    year1: '১ বছর',
    legalCompliance: 'আইনি এবং সম্মতি',
    legalDesc: 'এই অ্যাপটি ভারতীয় গোপনীয়তা আইন এবং ডেটা সুরক্ষা মান মেনে চলে।',
    accountSecurity: 'অ্যাকাউন্ট এবং নিরাপত্তা',
    logout: 'লগআউট',
  },
};

// Fallback to English if translation not available
export function getTranslation(langCode: string): Translations {
  return translations[langCode] || translations['en'];
}
